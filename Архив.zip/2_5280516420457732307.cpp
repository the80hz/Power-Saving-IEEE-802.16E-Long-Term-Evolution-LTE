/** Документация к программе
	ФИО: Панюшкин Андрей Михайлович
	номер группы: 6113
	Цели и Задачи (17 вариант): Дан список символов. Сформировать два списка: список
	символов и список целых чисел. В список символов поместить все символы без
	повторов, присутствующие в исходном списке, впорядке их появления, а в список
	целых - количество повторов этих символов в исходном списке.
**/

#include <windows.h>
#include <iostream>

struct Node
{
    char data;
    char tmpdata;
    int count;
    Node* next;
};
struct NodeNew
{
    char newdata;
    int newcount;
    NodeNew* next;
};
void clear(Node** head){
    while (*head){
        Node* tmp= *head;
        *head = (*head)->next;
        free(tmp);
    }
}

void print1(NodeNew* head) // Вывод списка 1
{
    printf("\nНовые списки:");
    NodeNew* h = head;
    printf("\nПервый список ( data ): \n");
    while (head != NULL)
    {
        printf("[%c]->", head->newdata);
        head = head->next;
    }
    printf("\nВторой список ( numbers ): \n");
    while (h != NULL)
    {
        printf("[%d]->", h->newcount);
        h = h->next;
    }
}
void print0(Node* head) // вывод исходного списка
{
    printf("Исходный список: \n");
    while (head != NULL)
    {
        printf("[%c]->", head->data);
        head = head->next;
    }
    printf("\n");
}
NodeNew* StackData(Node* h, int N, int number) // Формирование нового списка
{
    NodeNew* end = NULL;
    NodeNew* head = NULL;
    int i = 0;
    while (h != NULL)
    {
        if (h->tmpdata != ' ')
        {
            NodeNew* tmp = (NodeNew*)malloc(sizeof(NodeNew)); // memory
            tmp->newdata = h->tmpdata;
            tmp->newcount = h->count;
            tmp->next = NULL;
            if (i == 0)
            {
                head = tmp;
                end = tmp;
            }
            else
            {
                end->next = tmp;
                end = tmp;
            }
            i++;
        }
        h = h->next;
    }
    print1(head);
    return head;
}
Node* edit(Node* head, int N) // Фильтр списка (измение списка программой)
{
    Node* s;
    Node* e = head;
    Node* h = head;
    Node* f = head;
    int j = 1;
    int number = 0;
    while (head != NULL)
    {
        if (head->data != ' ')
            number++;
        head->tmpdata = head->data;
        head->count = 1;
        s = head;
        s = s->next;
        for (int i = j; i < N; i++)
        {
            if (s->data == head->tmpdata)
            {
                s->data = ' ';
                head->count += 1;
            }
            s = s->next;
        }
        j++;
        head = head->next;
    }
    StackData(e, N, number);
    return 0;
}
Node* add(Node* head, int N) // Добавление данных в список
{
    Node* end = NULL;
    for (int i = 0; i < N; i++)
    {
        Node* tmp = (Node*)malloc(sizeof(Node)); // memory
        printf("Введите значение в %d узел списка--> ", i + 1);
        scanf_s("%c", &tmp->data);
        // proverka on the enter
        while (tmp->data == '\n')
            scanf_s("%c", &tmp->data);
        tmp->next = NULL;
        if (i == 0)
        {
            head = tmp;
            end = tmp;
        }
        else
        {
            end->next = tmp;
            end = tmp;
        }
    }
    print0(head);
    edit(head, N);
    return head;
}
void numbersNode() // Указание кол-ва узлов в списке
{
    Node* head = NULL;
    int N, command;
    while (true)
    {
        printf("\nПожалуйста введите кол-во узлов в списке--> ");
        scanf_s("%d", &N);
        if (N < 0)
            printf("Error! N >= 0!!!");
        else if (N == 0)
        {
            printf("Что?? Пустой список! Вывести этот список (1) или вернуться в главное меню (another)?: \n");
            scanf_s("%d", &command);
            break;
        }
        else
        {
            command = 1;
            break;
        }
    }
    if (command == 1)
    {
        printf("goto --> edit\n");
        add(head, N);
    }
    else
        printf("goto --> bye....\n");
}
int main()
{
    SetConsoleOutputCP(CP_UTF8); //Задает выходную кодовую страницу,
    printf("|____________________________________________________|\n");
    printf("|     Лабораторная работа номер 1 ( 17 вариант )     |\n");
    printf("|____________________________________________________|\n");
    int command;
    while (true)
    {
        printf("\nВведите 1 для запуска и 2 для выхода: ");
        scanf_s("%d", &command);
        if (command == 1)
            numbersNode();
        else if (command == 2)
            break;
        else
            printf("Ошибка! Не могу найти такой команды! Попробуйте еще раз!\n");
    }
    return 0;
}


